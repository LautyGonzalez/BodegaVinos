﻿namespace BodegaVinos.Models
{
    public class Credentials
    {
        public string Password { get; set; }
        public string Username { get; set; }
    }
}